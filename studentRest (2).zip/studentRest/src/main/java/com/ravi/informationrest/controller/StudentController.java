package com.ravi.informationrest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ravi.studentRest.entities.Student;
import com.ravi.studentRest.repos.StudentRepository;

@RestController
@RequestMapping("/students")
public class StudentController {
	
	
	
	
	@Autowired
	StudentRepository studentRepository;

	/*
	 * @PostMapping("/data") public void postMethod() {
	 * 
	 * Student student = new Student(); student.setName("ravi");
	 * student.setAddress("bvrm"); studentRepository.save(student);
	 * 
	 * }
	 */
	
	
	@PostMapping
	public Student postMethod(@RequestBody Student student) {

		return studentRepository.save(student);

	}

}
