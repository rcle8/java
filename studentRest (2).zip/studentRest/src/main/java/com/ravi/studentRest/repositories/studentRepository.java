package com.ravi.studentRest.repositories;

public interface studentRepository {

}
