package com.ravi.studentRest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ravi.studentRest.dto.ApiResponse;
import com.ravi.studentRest.entities.Student;
import com.ravi.studentRest.repos.StudentRepository;

@RestController
@RequestMapping("/students")
public class StudentController {
	
	
	
	
	@Autowired
	StudentRepository studentRepository;

	@PostMapping("/data")
	public void postMethod() {

		Student student = new Student();
		student.setName("dev");
		student.setAddress("bvrm");
		studentRepository.save(student);

	  }
	 
	
	
	
		@PostMapping
		public Student postMethod(@RequestBody Student student) {

			return studentRepository.save(student);

		}
	 
       
		
		@GetMapping
		public List<Student> getall() {

			return studentRepository.findAll();
		}
		
		
		@GetMapping("/{sid}")
		public ResponseEntity<ApiResponse> getMethod(@PathVariable(value="sid") int sid) {
			ApiResponse apiResponse = new ApiResponse();
			Optional<Student> s = studentRepository.findById(sid);
			if(s.isPresent()) {
				Student byId = studentRepository.getById(sid);
				  apiResponse.setSuccess(true);
				  apiResponse.setData(byId);
				  studentRepository.findById(sid).get();
				 return ResponseEntity.ok(apiResponse);
			} else {

				apiResponse.setSuccess(false);
				apiResponse.setMessage("id not found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiResponse);
			}
			
			}
		
		
		@PutMapping("/{id}")
		public ResponseEntity<ApiResponse> updateMethod(@PathVariable(value="id") int id, @RequestBody Student student) {
			ApiResponse apiResponse = new ApiResponse();

			Optional<Student> s = studentRepository.findById(id);
			System.out.println(s.toString());
			if (s.isPresent()) {
				Student byId = studentRepository.getById(id);
				byId.setName(student.getName());
				byId.setAddress(student.getAddress());
				apiResponse.setSuccess(true);
				apiResponse.setData(student);
				studentRepository.save(byId);
	            
				return ResponseEntity.ok(apiResponse);

			} else {

				apiResponse.setSuccess(false);
				apiResponse.setMessage("id not found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiResponse);
			}
			
			
		}
		
		
		@DeleteMapping("/{id}")
		public ResponseEntity<ApiResponse> deleteMethod(@PathVariable(value = "id") int id){
			
			System.out.println(id);
			ApiResponse apiResponse = new ApiResponse();
			Optional<Student> s = studentRepository.findById(id);
			if(s.isPresent()) {
				Student student =studentRepository.getById(id);
				apiResponse.setSuccess(true);
				apiResponse.setData(student);
				studentRepository.delete(student);
				return ResponseEntity.ok(apiResponse);
			}
			else {
				apiResponse.setSuccess(false);
				apiResponse.setMessage("id not found");
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiResponse);
			}
}
}
