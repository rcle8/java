package com.ravi.studentRest.controller;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.ravi.studentRest.entities.Student;
import com.ravi.studentRest.repos.StudentRepository;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class StudentControllerTest {
   
	
     
	
	@InjectMocks
	StudentController studentController;
	
	@Mock
	StudentRepository studentRepository;
	
	
	
	@Test
	public void postmethod() {
		
	    Student student=new Student();
	    student.setName("ravi");
	    student.setAddress("bvrm");
		Mockito.when(studentRepository.save(student)).thenReturn(student);
		studentController.postMethod();
	}
	
	@Test
	public void postmethod1() {
		Student student=new Student();
		student.setName("ravi");
	    student.setAddress("bvrm");
		Mockito.when(studentRepository.save(student)).thenReturn(student);
		studentController.postMethod(student);
	}
	
	
	@Test
	public void getmethodn() {
		
		studentController.getall();
	}
	
	
	@Test
	public void getmethodwithid() {
		Student student=new Student();
		student.setName("ravi");
		student.setAddress("la");
		Optional<Student> s = Optional.of(student);
		Mockito.when( studentRepository.findById(1)).thenReturn(s);
		studentController.getMethod(1);
	}
	
	@Test
	public void getmethodwithid1() {
		studentController.getMethod(1);
	}
	
	@Test
	public void updatemethod() {
		Student student=new Student();
		studentController.updateMethod(1, student);
		
	}
	
	@Test
	public void updatemethod1() {
		
		Student student=new Student();
		student.setName("ravi");
		student.setAddress("bvrm");
		Optional<Student> s = Optional.of(student);
		Mockito.when(studentRepository.findById(1)).thenReturn(s);
		Student a = new Student();
		a.setName("chandu");
		a.setName("vij");
		Mockito.when(studentRepository.getById(1)).thenReturn(a);
		studentController.updateMethod(1, student);
		
		
	}
	
	@Test
	public void deletemethod() {
		Student student=new Student();
		student.setName("ravi");
		student.setAddress("bvrm");
		Optional<Student> s = Optional.of(student);
		Mockito.when(studentRepository.findById(1)).thenReturn(s);
		studentController.deleteMethod(1);
	}
	
	@Test
	public void deletemethod1() {
		studentController.deleteMethod(1);
	}
}
